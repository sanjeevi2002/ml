import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Sample dataset
data = {
    'age': [25, 30, np.nan, 35, 40, 22],
    'income': [50000, 70000, 60000, np.nan, 80000, 90000],
    'gender': ['Male', 'Female', 'Female', 'Male', 'Male', 'Female'],
    'purchased': ['No', 'Yes', 'No', 'Yes', 'Yes', 'No']
}

df = pd.DataFrame(data)

# Step 1: Handling missing data
# Impute missing values in 'age' and 'income' with their mean values
imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
df[['age', 'income']] = imputer.fit_transform(df[['age', 'income']])

# Step 2: Encoding categorical data
# Use ColumnTransformer to apply OneHotEncoder to the 'gender' column (index 2)
ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(), ['gender'])], remainder='passthrough')
df_encoded = pd.DataFrame(ct.fit_transform(df))

# Step 3: Feature scaling
# Standardize the numerical data
scaler = StandardScaler()
# Standardize the columns except for the last column (target variable 'purchased')
df_scaled = pd.DataFrame(scaler.fit_transform(df_encoded.iloc[:, :-1]))

# Step 4: Splitting the dataset into training and testing sets
# Separate features and target variable
X = df_scaled
y = df_encoded.iloc[:, -1]

# Split the dataset into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Display the processed data
print("Original DataFrame:")
print(df)

print("\nDataFrame after handling missing data and encoding categorical data:")
print(df_encoded)

print("\nDataFrame after scaling numerical data:")
print(df_scaled)

print("\nTraining and Testing sets:")
print("X_train:\n", X_train)
print("\nX_test:\n", X_test)
print("\ny_train:\n", y_train)
print("\ny_test:\n", y_test)

